# lambdas/students_writer/app.py
import os, json, boto3, psycopg2

ssm = boto3.client("ssm")
SSM_BASE = os.getenv("SSM_BASE", "/servicios-nube/dev")


def _get_param(name, decrypt=True, required=True, default=None):
    try:
        resp = ssm.get_parameter(Name=name, WithDecryption=decrypt)
        return resp["Parameter"]["Value"]
    except ssm.exceptions.ParameterNotFound:
        if required and default is None:
            raise
        return default


def _get_db_conn_params():
    host = _get_param(f"{SSM_BASE}/db/host", decrypt=False)
    port = int(_get_param(f"{SSM_BASE}/db/port", decrypt=False))
    name = _get_param(f"{SSM_BASE}/db/name", decrypt=False)

    # Preferir usuario de APP
    user = _get_param(f"{SSM_BASE}/app/db_user", decrypt=False, required=False)
    pwd = _get_param(
        f"{SSM_BASE}/app/db_password", decrypt=True, required=False
    )

    # Fallback a master
    if not user or not pwd:
        user = _get_param(f"{SSM_BASE}/db/user", decrypt=False)
        pwd = _get_param(f"{SSM_BASE}/db/master_password", decrypt=True)

    return dict(
        host=host,
        port=port,
        dbname=name,
        user=user,
        password=pwd,
        connect_timeout=5,
    )


def _normalize_payload(body: dict):
    # 1) batch
    if "students" in body and isinstance(body["students"], list):
        out = []
        for s in body["students"]:
            out.append(
                {
                    "nombre": s.get("nombre") or s.get("name") or "",
                    "apellido": s.get("apellido") or s.get("lastname") or "",
                    "correo": s.get("correo") or s.get("email"),
                }
            )
        return out

    # 2) pares simples
    if "name" in body or "nombre" in body:
        return [
            {
                "nombre": body.get("nombre") or body.get("name") or "",
                "apellido": body.get("apellido") or body.get("lastname") or "",
                "correo": body.get("correo") or body.get("email"),
            }
        ]

    # 3) legado n1/e1, n2/e2
    if "n1" in body and "e1" in body:
        out = [{"nombre": body["n1"], "apellido": "", "correo": body["e1"]}]
        if "n2" in body and "e2" in body:
            out.append(
                {"nombre": body["n2"], "apellido": "", "correo": body["e2"]}
            )
        return out

    return []


def handler(event, ctx):
    try:
        body = json.loads(event.get("body") or "{}")
    except Exception:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "JSON inválido"}),
        }

    rows = _normalize_payload(body)
    if not rows or any(not r.get("correo") for r in rows):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "payload inválido"}),
        }

    try:
        conn_params = _get_db_conn_params()
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"SSM faltante: {str(e)}"}),
        }

    conn = psycopg2.connect(**conn_params)
    try:
        with conn, conn.cursor() as cur:
            for r in rows:
                cur.execute(
                    """
                    INSERT INTO public.estudiante (nombre, apellido, correo_electronico)
                    VALUES (%s,%s,%s)
                    ON CONFLICT (correo_electronico) DO NOTHING
                """,
                    (r["nombre"], r.get("apellido", ""), r["correo"]),
                )
        return {
            "statusCode": 201,
            "body": json.dumps({"ok": True, "inserted": len(rows)}),
        }
    finally:
        conn.close()
